function [ fg_gmm, bg_gmm ] = fit_color_distribution( img, labels, k )


end

