function labels = graphcut(px_cnt, unary, pairwise)

    h = GCO_Create(px_cnt,2);   		% create graph cut object
    GCO_SetDataCost(h,int32(unary));	% set unary potentials
    GCO_SetNeighbors(h,pairwise);		% set the neighborhood
    GCO_Expansion(h);					% perform a single graph cut
    labels=GCO_GetLabeling(h);
    GCO_Delete(h);
    
end