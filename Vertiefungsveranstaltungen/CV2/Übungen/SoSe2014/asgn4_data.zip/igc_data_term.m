function D = igc_data_term( img, fg_gmm, bg_gmm)

end

