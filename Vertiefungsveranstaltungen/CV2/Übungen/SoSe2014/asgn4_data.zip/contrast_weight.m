function [ W ] = contrast_weight( img, Ed )

end

