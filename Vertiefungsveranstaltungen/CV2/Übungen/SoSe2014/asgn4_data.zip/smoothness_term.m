function S = smoothness_term( n, Ed, W, lambda )

end

