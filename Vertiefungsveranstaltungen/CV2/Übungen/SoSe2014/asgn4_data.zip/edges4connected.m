function E = edges4connected(height,width)
    % EDGE4CONNECTED Creates edges where each node
    %   is connected to its four adjacent neighbors on a 
    %   height x width grid.
    %   E - a matrix in which each row i represents an edge
    %   E(i,1) --> E(i,2).

    % YOUR CODE HERE
end