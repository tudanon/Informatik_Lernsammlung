function labels = iterated_graphcuts(img, win, lambda, k)

end