function llh_map = lapllh(i0_crop, i1, d, row, col)

    % YOUR CODE HERE
    
end

