function labels = alphaexpansion(i0, i1, dgt, row, col, Ed, labels, label_list, lambda)

    % YOUR CODE HERE
    
    %while ...
        
        % unary = ...
        % pairwise = ...
    
        % gc_labels = graphcut(foo, unary, pairwise);

        % ...
    %end    
end
