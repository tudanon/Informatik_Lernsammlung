%
% Computer Vision 2 - Assignment 4, Problem 1
%

close all;
clear;

% add path to GCO Optimization
addpath('gco/matlab/');

% set parameters
lambda=1;
k=5;

% read the image
img = im2double(imread('img_1.jpg')).*255;


% define window
t=6; h=164; l=21; w=191;
win = [t,h,l,w];

% get segmentation
labels = iterated_graphcuts(img, win, lambda, k);

% display results
fg_idx = labels==1;
fg_idx = repmat(fg_idx,[1,1,3]);

img_seg = img;
img_seg(~fg_idx) = 0;
figure(1); clf;
imshow(img_seg/255);