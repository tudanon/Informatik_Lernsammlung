%
% Computer Vision 2 - Assignment 4
%

% add path to GCO Optimization
addpath('gco/matlab/');

% set smoothness parameter
lambda=2;

% read the two images and the ground truth and convert to grayscale double
% YOUR CODE HERE

% crop images to available ground truth size.
% row and col represent the valid range in the image.
[row,col] = find(dgt);
% you can cut the images down like this
%dgt = dgt(min(row):max(row),min(col):max(col)); 


% create edges
% Ed = edges4connected(...);

% create label_list
% YOUR CODE HERE

% a-expansion with uniform label initialization
% YOUR CODE HERE

% a-expansion with random random initialization
% YOUR CODE HERE