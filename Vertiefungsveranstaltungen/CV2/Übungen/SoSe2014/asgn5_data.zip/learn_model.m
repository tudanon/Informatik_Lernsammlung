function [A, W, H, Q] = kalman_estimate(X, Z)
  % estimates kalman parameters from training data
  %
  % Inputs:
  %   X:  states as M x d matrix.
  %       M is the number of states, 
  %       d is the number of dimensions
  %   Z:  measurements as M x d matrix. 
  %       M is the number of measurements, 
  %       d is the number of dimensions
  %
  % Outputs:
  %   A:  State transition model
  %   W:  Covariance of process noise
  %   H:  Observation model
  %   Q:  Covariance of measurement noise
  %   
      
  %
  % YOUR CODE HERE
  %
end