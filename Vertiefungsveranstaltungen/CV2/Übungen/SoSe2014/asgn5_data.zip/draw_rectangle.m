function annotated_image = draw_rectangle(image, position, width, height)
  % takes a graylevel image as input and draws a colored
  % rectangle at position with specified height and width
  %
  % Inputs:
  %   image:      grayscale image
  %   position:   position of rectangle, [row; column]
  %   width:      width of rectangle
  %   height:     height of the rectangle
  %
  % Outputs:
  %   annotated_image:    image with rectangle, 3 channels
  %

  %
  % YOUR CODE HERE
  %
end