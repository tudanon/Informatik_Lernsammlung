function movie = annotate_video(images, numFrames, frame_size, object_size, positions)
  % make an annotated movie from images
  %
  % Inputs:
  %   images:         images to be annotated, numFrames x (r * c) matrix
  %   numFrames:      number of frames in the video
  %   frame_size:     size of the images in [row; column]
  %   object_size:    size of the object in [row; column]
  %   positions:      position of object within frame, as 
  %                   numFrames x 2 matrix, where each row represents a
  %                   position row, column
  % Outputs:
  %   movie:          Matlab movie with a bounding box in each frame
  %                   indicating the position of the tracked object.
  %

  %
  % YOUR CODE HERE
  %
end