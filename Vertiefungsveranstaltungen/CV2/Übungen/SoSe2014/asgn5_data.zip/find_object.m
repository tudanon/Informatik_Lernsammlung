function position = find_object(image, object, x)
  % finds an object in an image starting at an initial estimated position
  % using sum of squared differences (ssd)
  %
  % Inputs:
  %   image:              image where the object is hidden, rows x columns
  %                       matrix
  %   object:             image of the object to be found
  %   x:                  where the object might be, [column; row].
  %
  % Outputs:
  %    position:          where we found the object, 2 x 1 vector
  %
    
  %
  % YOUR CODE HERE
  %
end