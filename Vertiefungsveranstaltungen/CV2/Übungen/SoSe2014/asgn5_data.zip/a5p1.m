function a5p1
  % load training data
  %
  % YOUR CODE HERE
  %

  % plot measurements and states of training data
  %
  % YOUR CODE HERE
  %

  % estimate A, W, H, Q
  [A, W, H, Q] = learn_model(X, Z);

  % load test data
  %
  % YOUR CODE HERE
  %

  % set initial state estimate
  x0 = Z(1,:)';

  % compute kalman states
  measureHandle = @(z) z;
  Y = kalman_filter(A, W, H, Q, Z, measureHandle, x0, size(Z, 2));

  % plot measurements, hidden states, kalman states of test data
  %
  % YOUR CODE HERE
  %
end