function [A, W, H, Q] = init_ball_model()
  % set estimates for ball example
  %
  % Outputs:
  %   A:  State transition model
  %   W:  Covariance of process noise
  %   H:  Observation model
  %   Q:  Covariance of measurement noise
  %   

  % set state transition model
  % A = ;
  %
  % YOUR CODE HERE
  %


  % set observation model
  % H = ;
  %
  % YOUR CODE HERE
  %


  % set process noise
  % W = ;
  %
  % YOUR CODE HERE
  %


  % set mesurement noise
  % Q = ;
  %
  % YOUR CODE HERE
  %
end