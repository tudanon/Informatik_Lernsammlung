% Compute the log-likelihood of y given x
% using a Gaussian model with standard deviation sigmaN.
function llh = denoising_llh(x, y, sigmaN)

    % YOUR CODE GOES HERE

    assert(numel(llh)==1)
end