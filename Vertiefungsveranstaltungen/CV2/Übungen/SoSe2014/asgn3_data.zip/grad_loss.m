function g = grad_loss(x_gt, x)

    % YOUR CODE GOES HERE
    
    assert(all(size(g)==size(x)))
end