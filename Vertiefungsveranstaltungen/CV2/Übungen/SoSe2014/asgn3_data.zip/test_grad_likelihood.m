% Check whether the analytically computed gradient is correct
function d = test_grad_likelihood(x, y, sigmaN)

    idx_all = reshape(1:numel(x),size(x));
    
    % for speed reasons: only check a random selection of pixels
    idx = randsample(idx_all(:),100);

    d = test_grad(@(x) denoising_llh(x, y, sigmaN), ...
                  @(x) denoising_grad_llh(x, y, sigmaN), ...
                  x, idx);

    assert(max(d(:)) < 1e-5, ...
         'DEBUG: ''denoising_grad_llh'' seems to differ too much from the numerical approximation.');
    disp('DEBUG: ''denoising_grad_llh'' seems to be okay.');
end