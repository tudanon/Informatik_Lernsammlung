function xtcurrent = gradientascent_inp(x, M, sigma, alpha)

    % YOUR CODE GOES HERE
    
    assert(all(size(xtcurrent)==size(x)))
end