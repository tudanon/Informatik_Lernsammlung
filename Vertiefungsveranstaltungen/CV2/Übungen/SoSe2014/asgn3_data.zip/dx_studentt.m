% Compute the gradient of the log student-t distribution
function f = dx_studentt(x, sigma, alpha)

    % YOUR CODE GOES HERE

    assert(all(size(f)==size(x)))
end