% Compute the gradient (w.r.t. x) of the log-likelihood of y given x
% using a Gaussian model with standard deviation sigmaN.
function g = denoising_grad_llh(x, y, sigmaN)
    
    % YOUR CODE GOES HERE

    assert(all(size(g)==size(x)))
end