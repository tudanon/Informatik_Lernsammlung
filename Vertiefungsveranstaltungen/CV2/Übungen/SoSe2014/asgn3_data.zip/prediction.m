function [f, dsigma, dalpha] = prediction(x, y, sigmaN, sigma, alpha)

    % YOUR CODE GOES HERE

    assert(all(size(f)==size(x)))
    assert(all(size(dsigma)==size(x)))
    assert(all(size(dalpha)==size(x)))
end