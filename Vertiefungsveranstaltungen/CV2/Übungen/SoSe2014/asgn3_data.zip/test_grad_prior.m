% Check whether the analytically computed gradient is correct
function test_grad_prior(x, sigma, alpha)

    idx_all = reshape(1:numel(x),size(x));
    
    % for speed reasons: only check corner pixels and a random selection of other pixels
    idx_corners = sub2ind(size(x),[1 1 size(x,1) size(x,1)],[1 size(x,2) 1 size(x,2)]);
    idx_interior = idx_all(2:end-1,2:end-1);
    idx_boundary = setdiff(idx_all(:), idx_interior(:));
    idx = [idx_corners(:); randsample(idx_boundary(:),100); randsample(idx_interior(:),100)];

    d = test_grad(@(x) mrf_log_prior(x, sigma, alpha), ...
                  @(x) mrf_grad_log_prior(x, sigma, alpha), ...
                  x, idx);

    assert(max(d(:)) < 1e-5, ...
         'DEBUG: ''mrf_grad_log_prior'' seems to differ too much from the numerical approximation.');
    disp('DEBUG: ''mrf_grad_log_prior'' seems to be okay.');
end