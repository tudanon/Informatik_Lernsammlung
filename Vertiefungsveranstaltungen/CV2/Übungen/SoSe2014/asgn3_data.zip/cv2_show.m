function cv2_show(img,t)
    if ~exist('t','var'), t = ''; end
    imagesc(img)
    axis image
    title({t})
    colormap(gray(256))
end