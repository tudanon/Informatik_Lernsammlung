% Computer Vision II (SS 14) - Assignment 3 - Problem 2
function problem2

    img = cv2_read('images/la.png');

    disp('Gausian noise added to an image');
    % TODO: Load image, add Gaussian noise, show the result.

    % YOUR CODE GOES HERE

    pause; close all

    disp('Denoising the image (parameter setting 1)');
    % TODO: Remove noise using gradient ascent, show the result, compute PSNR.

    % YOUR CODE GOES HERE

    pause; close all

    disp('Denoising the image (parameter setting 2)');
    % TODO: Remove noise using gradient ascent, show the result, compute PSNR.

    % YOUR CODE GOES HERE

    pause; close all;

end