function d = test_grad(func,func_grad,x,idx)
    if ~exist('idx','var'), idx = 1:numel(x); end
    epsilon = 1e-5;
    g_ref   = func_grad(x);
    g       = zeros(size(idx));

    for ii = 1:numel(idx)
        % fprintf('checking pixel %d of %d\n', ii, numel(idx))
        i = idx(ii);
        xp = x; xp(i) = x(i) + epsilon;
        xm = x; xm(i) = x(i) - epsilon;
        g(ii) = (func(xp) - func(xm)) / (2*epsilon);
    end

    d = abs(g-g_ref(idx));
end