function img = cv2_read(filename)
    img = double(imread(filename));
end
