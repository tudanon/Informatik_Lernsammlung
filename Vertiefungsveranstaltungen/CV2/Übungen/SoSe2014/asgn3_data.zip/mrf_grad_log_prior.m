% Compute the gradient of the log-MRF prior with respect to image x 
% using t-distribution potentials with parameters sigma and alpha.
function g = mrf_grad_log_prior(x, sigma, alpha)

    % YOUR CODE GOES HERE

    assert(all(size(g)==size(x)))
end 