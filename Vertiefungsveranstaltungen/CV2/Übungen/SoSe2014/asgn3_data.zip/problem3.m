% Computer Vision II (SS 14) - Assignment 3 - Problem 3
function problem3

    img = cv2_read('images/castle.png');

    disp('Image with 50% of the pixels missing');
    % TODO: Create random binary mask. Mask input image, show the result.

    % YOUR CODE GOES HERE

    pause; close all

    disp('Inpainting (50% missing)');
    % TODO: Inpaint using gradient ascent, show the result.

    % YOUR CODE GOES HERE

    pause; close all

    disp('Image with 80% of the pixels missing');
    % TODO: Create random binary mask. Mask input image, show the result.

    % YOUR CODE GOES HERE

    pause; close all

    disp('Inpainting (80% missing)');
    % TODO: Inpaint using gradient ascent, show the result.

    % YOUR CODE GOES HERE

    pause; close all

end