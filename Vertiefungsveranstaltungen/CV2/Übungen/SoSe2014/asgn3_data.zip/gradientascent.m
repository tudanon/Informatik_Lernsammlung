function xtcurrent = gradientascent(x, sigmaN, sigma, alpha)

    % YOUR CODE GOES HERE
    
    assert(all(size(xtcurrent)==size(x)))
end