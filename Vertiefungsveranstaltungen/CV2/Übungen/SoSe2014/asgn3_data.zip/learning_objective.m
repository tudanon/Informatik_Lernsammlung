function [J, g] = learning_objective(x_gt, x, y, sigmaN, sigma, alpha)

  % YOUR CODE GOES HERE

  assert(numel(J)==1)
  assert(all(size(g)==[2,1]))
end
