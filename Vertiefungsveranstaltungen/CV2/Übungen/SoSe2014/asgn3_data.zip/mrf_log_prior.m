% Compute the log of an unnormalized pairwise MRF prior for disparity map x
% using t-distribution potentials with parameters sigma and alpha.
function lp = mrf_log_prior(x, sigma, alpha)

  dh = x(1:end-1,:)-x(2:end,:);
  dv = x(:,1:end-1)-x(:,2:end);

  lp = sum(studentt(dh(:), sigma, alpha)) + ...
       sum(studentt(dv(:), sigma, alpha));
end

function f = studentt(x, sigma, alpha)
    % take the log of the given equation for student-t distribution
    f = -alpha * log(1 + (x.^2)/(2*sigma^2));
end