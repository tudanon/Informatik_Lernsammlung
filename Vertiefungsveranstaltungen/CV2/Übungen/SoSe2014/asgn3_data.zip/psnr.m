% Peak signal-to-noise ratio
function p = psnr(x_gt, x)

    % YOUR CODE GOES HERE

    assert(numel(p)==1)
end