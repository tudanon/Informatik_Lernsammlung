% Computer Vision II (SS 14) - Assignment 3 - Problem 4
function problem4
    
    x_gt = cv2_read('images/la.png');
    y    = cv2_read('images/la-noisy.png'); sigmaN = 15;
    
    theta0  = [10; 1];
    func    = @(theta,x) learning_objective(x_gt, x, y, sigmaN, theta(1), theta(2));
    options = struct('DerivativeCheck','on');

    disp('Loss-based training for 1 iteration of gradient ascent');
    % TODO: Denoise y with learned values, compute PSNR, show it.

    theta_hat = minFunc(func,theta0,options,y);

    % YOUR CODE GOES HERE

    pause; close all

    disp('Loss-based training for 10 iterations of gradient ascent');
    % TODO: Denoise y with learned values, compute PSNRs, show results.

    % YOUR CODE GOES HERE

    pause; close all

end