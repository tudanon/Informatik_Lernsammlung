% Computer Vision II (SS 14) - Assignment 3 - Problem 1
function problem1

    img = cv2_read('images/la.png');

    disp('Gradient of the log-prior of LA image');
    % TODO: Compute and show gradient of the log-prior of the LA image.

    % YOUR CODE GOES HERE

    pause; close all


    disp('Gradient of log-prior of random noise image');
    % TODO: Compute and show gradient of log-prior of random noise image

    % YOUR CODE GOES HERE

    pause; close all

    disp('Gradient of log-prior of constant image');
    % TODO: Compute and show gradient of the log-prior of constant image. 

    % YOUR CODE GOES HERE

    pause; close all

end