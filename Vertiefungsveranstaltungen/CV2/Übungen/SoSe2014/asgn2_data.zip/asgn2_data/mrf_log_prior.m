function lp = mrf_log_prior(x, sigma, alpha)
% Computes the log of an unnormalized pairwise MRF prior for disparity 
% map x using t-distribution potentials with parameters sigma and alpha.

% ----- your code here -----	



lp = 0; % return your computed prior here
end