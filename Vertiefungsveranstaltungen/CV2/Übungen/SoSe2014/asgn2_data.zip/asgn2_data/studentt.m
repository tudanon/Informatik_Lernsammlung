function f = studentt(x, sigma, alpha)
% Calculates the potential based on Student's-t distribution

% ----- your code here -----


f = 0; % return your value here

end