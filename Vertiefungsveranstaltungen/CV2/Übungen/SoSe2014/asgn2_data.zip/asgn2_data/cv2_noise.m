function R = cv2_noise(s, a, b)
% Creates a random noise image of size s with values in the range [a, b].

% ----- your code here -----



R = 0; % return your value here

end