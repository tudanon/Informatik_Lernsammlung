function C = cv2_constant(s, a)
% Creates a constant image of size s and value a

% ----- your code here -----



C = 0; % return your value here

end