function img = cv2_read(filename)
% Reads in the disparity map

% ----- your code here -----

img = zeros(1, 1); % return your value here

end