function cv2_show(img,text)
%show the image
imagesc(img);
%we have a grayscale image
%note: colormap('gray') has only 64 different gray values
colormap(gray(256));
%correct aspect ratio
axis image;
%no axis
axis off;
%title
title(text)