% - Task 2 --------------------------------------------------------------

disp('Log-prior of ground truth disparity map of Tsukuba dataset');

sigma = 1;
alpha = 1;

% read ground-truth data
X = cv2_read('gt.pgm');

% compute log prior and display result
lp = mrf_log_prior(X, sigma, alpha);
disp(['Log Prior is ' num2str(lp)]);

pause
close all;


% - Task 3 --------------------------------------------------------------

disp('Log-prior of random noise image');

% create random noise image
R = cv2_noise(size(X), 0, 16);

% compute log prior and display result
lp = mrf_log_prior(R, sigma, alpha);
cv2_show(R,['Log Prior is ' num2str(lp)]);
disp(['Log Prior is ' num2str(lp)]);

pause
close all;


% - Task 4 --------------------------------------------------------------

disp('Log-prior of constant image');

% create constant image
C = cv2_constant(size(X), 8);

% compute log prior and display result
lp = mrf_log_prior(C, sigma, alpha);
cv2_show(C, ['Log Prior is ' num2str(lp)]);
disp(['Log Prior is ' num2str(lp)]);

pause
close all;
