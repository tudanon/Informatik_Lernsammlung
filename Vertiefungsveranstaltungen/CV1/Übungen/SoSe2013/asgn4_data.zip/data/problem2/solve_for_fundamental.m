function F = solve_for_fundamental(p1, p2)
%% builds coefficent matrix and solves for fundamental matrix using svd.
%
% INPUTS:
%   p1
%   p2
%
% OUTPUTS:
%   F       fundamental matrix, rank 2
%
%% YOUR CODE GOES HERE
 
    
    %% enforce rank constraint
    F = enforce_rank(F, 2);
    
end