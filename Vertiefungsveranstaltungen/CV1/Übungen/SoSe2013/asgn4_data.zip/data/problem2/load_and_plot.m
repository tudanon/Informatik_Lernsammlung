function [p1, p2] = load_and_plot()
%% loads coordinates from impts.m and plots.