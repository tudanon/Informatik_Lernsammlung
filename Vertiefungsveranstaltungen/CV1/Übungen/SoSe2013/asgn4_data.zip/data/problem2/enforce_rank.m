function Mr = enforce_rank(M, r)
%% enforces rank by SVD
%
% INPUTS:
%   M       matrix
%   r       rank to enforce on M
% 
% OUTPUTS:
%   Mr      M, now with rank r   
%
%% YOUR CODE GOES HERE

   

end