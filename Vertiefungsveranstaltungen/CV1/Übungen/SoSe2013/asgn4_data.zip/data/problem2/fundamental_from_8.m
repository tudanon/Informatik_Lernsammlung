function [F, p1h, p2h] = fundamental_from_8(p1, p2)
%% computes fundamental matrix from 8 correspondences.
%
% INPUTS:
%   p1      8 points from 1st image
%   p2      8 points from 2nd image
%
% OUTPUTS:
%   F       fundamental matrix
%   p1h     p1 in homogenuous coordinates
%   p2h     p2 in homogenuous coordinates
%

    %% convert to homogenuous coordinates    
    %  YOUR CODE GOES HERE
   

    
    %% condition image coordinates       
    [cp1h, T1] = condition(p1h); 
    [cp2h, T2] = condition(p2h);
    
    %% % convert to homogeneous coordinates
    F = solve_for_fundamental(cp1h, cp2h);    
    
    %% unconditiong    
    %  YOUR CODE GOES HERE
   
    
end