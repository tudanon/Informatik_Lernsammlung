%% task 1 - load and plot the coordinates
[p1, p2] = load_and_plot();

%% task 2 - compute fundamental matrix
[F, points1h, points2h] = fundamental_from_8(p1, p2);

%% task 3 - check correctness

