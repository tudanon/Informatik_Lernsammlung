function [cx, T] = condition(x)
%% conditions coordinates by translating mean to (0,0) and scaling such that
%  all coordinates are in the interval [-1,1].
%
% INPUTS:
%   x       coordinates, [3 x n]-matrix
%
% OUTPUTS:
%   cx      conditioned coordinates, [3 x n]-matrix
%   T       transformation used for conditioning, [3 x 3]-matrix
%
%% YOUR CODE GOES HERE

    
end