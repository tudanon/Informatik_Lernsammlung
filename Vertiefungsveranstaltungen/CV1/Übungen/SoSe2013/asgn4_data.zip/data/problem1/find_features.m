function [features_x, features_y] = find_features(img)
%% finds corner points in an image.
%
% INPUTS:
%   img     image
%   
% OUTPUTS:
%   features_x  column vector of x-coordinates of feature points
%   features_y  column vector of y-coordinates of feature points
%
%% YOUR CODE GOES HERE

   
end
