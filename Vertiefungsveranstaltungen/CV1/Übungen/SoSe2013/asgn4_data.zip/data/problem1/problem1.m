%% load images
[img0, img1] = load_images();

%% task 1 - pre-smooth images
img0_smooth = presmooth(img0);
img1_smooth = presmooth(img1);

%% task 2 - spatial and temporal derivatives
[dx, dy, dt] = derive(img0_smooth, img1_smooth);

%% task 3 - find feature points
[features.x, features.y] = find_features(img0);
figure(1), imshow(img0 ./ 255), hold on, plot(features.x, features.y, 'xy');

%% task 4 - compute coefficients of linear system f equations
coefficients = compute_coefficients(dx, dy, dt);

%% task 5 - compute optical flow at all feature points
[u, v] = compute_flow(features, coefficients);

%% task 6 - display flow
display_flow(features, u, v, size(img0));






