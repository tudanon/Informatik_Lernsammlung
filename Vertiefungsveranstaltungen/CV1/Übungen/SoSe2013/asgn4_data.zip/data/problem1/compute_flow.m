function [u, v] = compute_flow(features, coefficients)
%% computes optical flow at all feature points
%
% INPUTS:
%   features        structure with members:
%       x           column vector of x-coordinates of feature points
%       y           column vector of y-coordinates of feature points
%   coefficients    structure with members:
%       dx2         smoothed square of x-derivative
%       dxdy        smoothed product of x- and y-derivative
%       dy2         smoothed square of y-derivative
%       dxdt        smoothed product of x- and temporal derivative
%       dydt        smoothed product of y- and temporal derivative
%
% OUTPUTS:
%   u               column vector of horizontal flow component at feature
%                   points
%   v               column vector of vertical flow component at feature
%                   points
%% YOUR CODE GOES HERE

    
end