function [frame9, frame10] = load_images()
%% loads frames 9 and 10.
%
% OUTPUTS:
%   frame9
%   frame10
%
%% YOUR CODE GOES HERE

  
end