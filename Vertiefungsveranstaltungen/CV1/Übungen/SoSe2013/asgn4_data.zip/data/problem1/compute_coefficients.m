function coefficients = compute_coefficients(dx, dy, dt)
%% computes coefficients of linear system f equations
%
% INPUTS:
%   dx      derivative in x-direction
%   dy      derivative in y-direction
%   dt      temporal derivative
%
% OUTPUTS:
%   coefficients    structure with members:
%       dx2         smoothed square of x-derivative
%       dxdy        smoothed product of x- and y-derivative
%       dy2         smoothed square of y-derivative
%       dxdt        smoothed product of x- and temporal derivative
%       dydt        smoothed product of y- and temporal derivative
%
%% YOUR CODE GOES HERE
    
   
end