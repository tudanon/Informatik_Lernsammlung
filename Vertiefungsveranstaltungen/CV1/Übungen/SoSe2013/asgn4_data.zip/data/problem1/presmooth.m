function smoothed = presmooth(img)
%% smoothes the image with a Gaussian filter.
%
% INPUTS:
%   img         image to be smoothed
%
% OUTPUTS:
%   smoothed    smoothed image
%
%% YOUR CODE GOES HERE

    
end