function [dx, dy, dt] = derive(img0, img1)
%% calculates derivatives dx, dy, dt.
%
% INPUTS:
%   img0    image at t
%   img1    image at t+1
%
% OUTPUTS:
%   dx      derivative in x-direction
%   dy      derivative in y-direction
%   dt      temporal derivative
%
%% YOUR CODE GOES HERE

    
    
end
  