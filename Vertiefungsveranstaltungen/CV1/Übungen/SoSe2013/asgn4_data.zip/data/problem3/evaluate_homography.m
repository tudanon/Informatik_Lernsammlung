function [num_inliers, idx_inliers] = evaluate_homography(H, p1, p2)
%% evaluates homography and returns number of inliers
%
% INPUTS:
%   H       homography
%   p1
%   p2
%
% OUTPUTS:
%   num_inliers     number of inliers
%   idx_inliers     indices of inliers
%
%% YOUR CODE GOES HERE

   

end
