%% task A1 - load images
% img_left = ; 
% img_right = ;
% right_half = ;
% left_half = ;


%% extract features from both images
[keypoints_left,  descriptors_left]  = extract_features(img_left, right_half);
[keypoints_right, descriptors_right] = extract_features(img_right, left_half);


%% task A2 - find correspondences
pairs  = find_matches(keypoints_left, descriptors_left, keypoints_right, descriptors_right);


%% task A3 - display matches



%% task A5 - estimate number of iterations
% percent_inliers = ;
% num_iterations  = ;
  

for s = 1:num_iterations
    
    %% task A6 - draw sample    
   
    
    % conditioning
    
    
    %% task A4 - compute homography    
    tH = compute_homography(cpt1h, cpt2h);
    
    % un-conditioning    
    
    
    %% task A7
    
end
  
  
  %% task A8 - show correspondences
  % YOUR CODE GOES HERE
  



%% task B1 - transform right image into image plane of left
  

%% task B2 - display panorama
