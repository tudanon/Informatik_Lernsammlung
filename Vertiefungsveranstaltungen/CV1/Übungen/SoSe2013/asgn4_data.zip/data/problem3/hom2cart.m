function x = hom2cart(xt)
  x = bsxfun(@rdivide, xt(1:end-1,:), xt(end,:));
end