function H = compute_homography(p1, p2)
%% computes homography
%
% INPUTS:
%   p1      points of first image
%   p2      points of second image
%
% OUTPUTS:
%   H       homography
%
%% YOUR CODE GOES HERE


   
end