function [keypoints, descriptors] = extract_features(img, mask)
%% extracts features from image
%
% INPUTS:
%   img     image
%   mask    mask, where to look for keypoints
%
% OUTPUTS:
%   keypoints       points detected by harris, structure with:
%       x           column vector of x-coordinates
%       y           column vector of y-coordinates
%   descriptors     descriptors extracted at keypoints
%
%% YOUR CODE GOES HERE

   
    
end
