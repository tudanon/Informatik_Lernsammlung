function coords = find_matches(keypoints1, descriptors1, keypoints2, descriptors2)
%% finds pairs between two descriptor sets using chi-square distance.
%
% INPUTS:
%   keypoints1      keypoints of 1st image
%   descriptors1    descriptors of 1st image
%   keypoints2      keypoints of 2nd image
%   descriptors2    descriptors of 2nd image
%
% OUTPUTS:
%   coords      [n x 4] matrix with n pairs and coordinates of keypoints
%               in order x1 y1 x2 y2 per row.
%
%% YOUR CODE GOES HERE

	
end
   