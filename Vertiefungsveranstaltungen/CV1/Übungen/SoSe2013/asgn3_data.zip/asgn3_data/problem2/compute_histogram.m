function histogram = compute_histogram(data)
%% computes the histogram over the codebook
%
% INPUTS:
%   data            structure with training data
%       codebook 
%       features
%       input       structure with input training data
%
% OUTPUTS:
%	histogram
%

%%  YOUR CODE GOES HERE

    

end