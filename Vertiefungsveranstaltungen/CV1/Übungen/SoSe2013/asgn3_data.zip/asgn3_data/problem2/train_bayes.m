function bayes_classifier = train_bayes(data)
%% Implement the naive Bayes classifier for separating motorbike and airplane images. Note you should also estimate the
%  class priors p(Cj) according to the training data.
%
% INPUTS:
%   data                training data
%
% OUTPUTS:
%    bayes_classifier
%       pc_c0           class-conditional probability class 0
%       pc_c1           class-conditional probability class 1
%       prior0          prior class 0
%       prior1          prior class 1
%
%%   YOUR CODE GOES HERE

 
end