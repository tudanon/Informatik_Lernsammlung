function [training_data, testing_data] = load_data()
%% Loads all airplane and motorbike images from the images/ subdirectory of the zip file. 
%  Randomly separates each image set into two equal-size parts for training and testing respectively.
%
% OUTPUTS:
%	training_data 		structure with fields following fields:
%		images 			(1 x number_of_images) cell array with training images
%		labels 			(1 x number_of_images) array
% 		num_samples 	number of images in training set
%
%	testing_data		structure with fields following fields:
%		images 			(1 x number_of_images) cell array with test images
%		labels 			(1 x number_of_images) array
% 		num_samples 	number of images in test set
%

%% YOUR CODE GOES HERE

   
end