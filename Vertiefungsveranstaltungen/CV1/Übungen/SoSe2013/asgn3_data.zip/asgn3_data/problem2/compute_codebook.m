function codebook = compute_codebook(features)
%% Computes the codewords (keypoints) using k-means clustering with k = 50. During the iterations, if any of the cluster
%  centers has no data points associated with it, we replace it with a random data point.
%
% INPUTS:
%	features
%
% OUTPUTS:
%	codebook
%
%%  YOUR CODE GOES HERE

   

end