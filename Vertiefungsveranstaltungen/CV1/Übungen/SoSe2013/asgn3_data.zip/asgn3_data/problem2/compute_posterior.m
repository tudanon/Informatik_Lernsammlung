function bayes_classifier = compute_posterior(bayes_classifier, data)
%%
% INPUTS:
%    bayes_classifier
%       pc_c0           class-conditional probability class 0
%       pc_c1           class-conditional probability class 1
%       prior0          prior class 0
%       prior1          prior class 1
%   data                training data
%
% OUTPUTS:
%    bayes_classifier
%       pc_c0           class-conditional probability class 0
%       pc_c1           class-conditional probability class 1
%       prior0          prior class 0
%       prior1          prior class 1
%       posterior0      posterior of class 0
%       posterior1      posterior of class 1
%
%%   YOUR CODE GOES HERE

    
end