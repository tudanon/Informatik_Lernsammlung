%%
% Bag-of-Words Model
%

%% task A1
[training.input, testing.input] = load_data();

%% task A2
params.filter_size = 0;
params.sigma 	   = 0;
params.threshold   = 0;
params.boundary    = 0;
training.features  = extract_features(training.input, params);

%% task A3
training.codebook  = compute_codebook(training.features);
training.histogram = compute_histogram(training);

%%
% Naive Bayes Classifier
%

%% task B1
bayes_classifier = train_bayes(training);

%% task B2
bayes_classifier = compute_posterior(bayes_classifier, training);

%% task B3
train_error = test_bayes(bayes_classifier, training);

%% task B4
%
%%  YOUR CODE GOES HERE



%%
% SVM Classifier
%
addpath('../problem1');

%% task C1
%%	YOUR CODE GOES HERE

  
%% task C2
%%	YOUR CODE GOES HERE
