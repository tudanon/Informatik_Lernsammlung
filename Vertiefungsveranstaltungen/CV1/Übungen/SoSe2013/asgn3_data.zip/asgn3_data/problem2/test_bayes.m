function error = test_bayes(bayes_classifier, data)
%% computes the error rate of bayes classifier on data
%
% INPUTS:
%   bayes_classifier    model of bayes classifier
%   data                data to test
%
% OUTPUTS:
%   error               error of the classifier on the provided data
%

%%  YOUR CODE GOES HERE

   
end