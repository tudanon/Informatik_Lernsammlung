function features = extract_features(data, params)
%% Applies the Harris detector and SIFT descriptor (sample code will be sent to you via mailinglist) to obtain the feature vectors
%  from the training images. Use the parameters s = 1:4 (for both Harris and SIFT), filter size 1515, threshold 1500 and
%  ignore the feature points within a 10-pixel wide boundary.
%
% INPUTS:
%   data
%   params              structure with parameters
%       sigma           scalar
%       threshold       scalar
%       boundary        scalar
%       filter_size     scalar
%
% OUTPUTS:
%   features
%
%
%% YOUR CODE GOES HERE


end