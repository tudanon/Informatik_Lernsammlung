function plot_before(data) 
%% Makes a scatter plot that allows to see which data point belongs to which class.
%
%% YOUR CODE GOES HERE

    
end