function plot_after(data, w, b, support_vectors)
%% Plot the decision boundary y(x) = wTx+b = 0 as well as the margin lines (see illustrations in the lecture slides) on top of
%  the scatter plot of the data. Note that the margin lines are also contour lines y(x) = c. (Which values of c do you need?)
%  Also mark the support vectors in the plot.
%
%% YOUR CODE GOES HERE

  
end