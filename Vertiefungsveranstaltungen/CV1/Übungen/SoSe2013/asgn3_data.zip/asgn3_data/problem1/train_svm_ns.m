function [w, b, support_vectors] = train_svm_ns(data, labels, C)
%% Trains the linear SVM (non-separable case) on the training data and reports what values of w and b we obtain.
%
% INPUTS:
%   data            training data
%   labels          training data
%   C
%
% OUTPUTS:
%   w
%   b
%   support_vectors
%
%% YOUR CODE GOES HERE

   


end