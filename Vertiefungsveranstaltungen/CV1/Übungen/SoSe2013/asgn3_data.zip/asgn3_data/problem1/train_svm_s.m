function [w, b, support_vectors] = train_svm(data, labels)
%% Trains the linear SVM on the training data and reports what values of w and b we obtain.
%
% INPUTS:
%   data            training data
%   labels          training labels
%
% OUTPUTS:
%   w
%   b
%   support_vectors
%
%% YOUR CODE GOES HERE

   
end