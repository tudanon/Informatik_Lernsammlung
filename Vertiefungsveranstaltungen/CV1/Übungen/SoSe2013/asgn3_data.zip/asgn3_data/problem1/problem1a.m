%% task A1
training_data = load_training_data();
plot_before(training_data);

%% task A3
[w, b, support_vectors] = train_svm_s(training_data(1:2,:), training_data(end, :))

%% task A4
disp('The solution has XX support vectors.');

%% task A5
plot_after(training_data, w, b, support_vectors);