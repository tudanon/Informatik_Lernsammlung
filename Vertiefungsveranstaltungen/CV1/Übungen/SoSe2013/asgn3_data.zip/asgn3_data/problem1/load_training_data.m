function data = load_training_data()
%% Loads the training data from a3p1_tdata.mat, where data points are stored in rows, the first two columns are features
%  and the last column gives the class.
%
% OUTPUTS:
%   data
%
%%  YOUR CODE GOES HERE


end