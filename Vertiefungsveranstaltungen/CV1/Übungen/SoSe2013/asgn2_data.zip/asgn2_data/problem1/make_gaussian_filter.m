%% create a Gaussian filter
function f = make_gaussian_filter(fsize, sigma)
    % your code goes here
end