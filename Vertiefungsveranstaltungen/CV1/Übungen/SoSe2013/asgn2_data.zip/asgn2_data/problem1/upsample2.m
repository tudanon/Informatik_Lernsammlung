%% upsample an image by factor of 2
function im = upsample2(lim)
    % your code goes here
end