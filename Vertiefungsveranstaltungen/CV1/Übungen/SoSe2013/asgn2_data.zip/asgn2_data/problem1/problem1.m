function problem1
    % your code goes here
end
