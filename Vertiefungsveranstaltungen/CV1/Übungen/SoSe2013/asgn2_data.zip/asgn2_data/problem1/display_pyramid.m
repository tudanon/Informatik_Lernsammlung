%% display pyramids
function display_pyramid(L)

    % your code goes here

end
