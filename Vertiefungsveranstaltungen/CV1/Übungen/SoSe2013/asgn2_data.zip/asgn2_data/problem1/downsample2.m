%% dowmsample an image by factor of 2
function im = downsample2(him)
    % your code goes here
end
