%% reconstruct the image from the Laplacian pyramid
function im = reconstruct_laplacianpyramid(L)
    % your code goes here
end