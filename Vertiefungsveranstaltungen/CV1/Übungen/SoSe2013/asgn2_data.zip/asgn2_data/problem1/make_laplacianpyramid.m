%% build Laplacian pyramid
function L = make_laplacianpyramid(im, nlevels)
    % your code goes here
end