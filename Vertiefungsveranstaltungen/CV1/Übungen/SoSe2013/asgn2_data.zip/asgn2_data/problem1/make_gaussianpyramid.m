%% build Gaussian pyramid
function G = make_gaussianpyramid(im, nlevels)
    % your code goes here
end