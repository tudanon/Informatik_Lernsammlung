function problem3
    % your code goes here
end

