%
% Loading face data
%
% data: linearized and concatenated image data with size MxN,
%       where M is is the number of face dimensions, and N
%       is the number of faces
% imdims: face image dimension [rows,colums]
% nfaces: number of faces
%
function [data, imdims, nfaces] = loadfaces
    file_dir = '../yale_faces';
    
    % your code goes here
end