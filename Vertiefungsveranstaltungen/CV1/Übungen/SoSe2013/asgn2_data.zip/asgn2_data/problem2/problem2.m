function problem2

  % load the face images
  [data, imdims, nfaces] = loadfaces;
 
  
  % the mean face and SVD
  
  % your code goes here
 
  
  % printing the percentage of variance
  
  % your code goes here
  
  
  % display mean face and the first 10 eigenfaces

  % your code goes here
  
  
  % face projection and reconstruction
  
  % your code goes here
end

